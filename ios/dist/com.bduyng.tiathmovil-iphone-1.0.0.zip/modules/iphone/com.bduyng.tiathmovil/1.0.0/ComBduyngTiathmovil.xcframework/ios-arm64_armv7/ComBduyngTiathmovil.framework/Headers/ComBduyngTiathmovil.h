//
//  ComBduyngTiathmovil.h
//  TiAthmovil
//
//  Created by Your Name
//  Copyright (c) 2019 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ComBduyngTiathmovil.
FOUNDATION_EXPORT double ComBduyngTiathmovilVersionNumber;

//! Project version string for ComBduyngTiathmovil.
FOUNDATION_EXPORT const unsigned char ComBduyngTiathmovilVersionString[];

#import "ComBduyngTiathmovilModuleAssets.h"
